/* Do not remove this file. Its needed for some 2.6 kernels
 * since some defines are missing
 */
#ifndef NR_IRQS
#define NR_IRQS 1
#endif

#ifndef NR_IRQ_VECTORS
#define NR_IRQ_VECTORS 1
#endif



